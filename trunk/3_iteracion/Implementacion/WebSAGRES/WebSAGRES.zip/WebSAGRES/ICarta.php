<?php

/**
 * Define la funcionalidad ofrecida por el Subsistema de Gestion de Carta al Controlador Principal
 * @author Adrián Víctor Pérez Lopera
 */
interface ICarta {
    function getSecciones();
}

?>