<?php

/**
 * Define la interactividad permitida con los datos de carta
 * @author Adrián Víctor Pérez Lopera
 */
interface ICartaBD {
    function getSecciones();
}

?>