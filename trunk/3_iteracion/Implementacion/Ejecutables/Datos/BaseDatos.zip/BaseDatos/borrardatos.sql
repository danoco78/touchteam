
delete from facturaPedido where 1;
delete from factura where 1;
delete from productoBebida where 1;
delete from productoIngrediente where 1;
delete from producto where 1;
delete from asociaPlato where 1;
delete from asociaBebida where 1;
delete from carta where 1;
delete from tieneElemento where 1;
delete from seccion where 1;
delete from elemento where 1;
delete from pedido where 1;
delete from elementoColaBar where 1;
delete from elementoColaCocina where 1;
delete from elementoPedido where 1;
delete from pedido where 1;
delete from factura where 1;
delete from facturaPedido where 1;



